// ShootDodge (C2SD-T37): Bullet Time mode's default key (/) through a game input action.
//
// r6/input/ShootDodge.xml (loaded by the Input Loader mod) defines the action ShootDodgeBulletTime,
// mapped to IK_Slash/IK_NumSlash in the on-foot Locomotion context. This file only listens for it: every fresh
// press is counted here, and the CET side (modules/BulletTimeKeyDriver.lua) takes the count each
// frame through Game.GetScriptableSystemsContainer():Get("ShootDodgeBulletTimeKeySystem") and
// toggles Bullet Time mode, debounced against the CET binding. Without Input Loader the action never
// fires and nothing here does anything; the file needs nothing but redscript.

public class ShootDodgeBulletTimeKeyListener {
  private let m_owner: wref<ShootDodgeBulletTimeKeySystem>;

  public func SetOwner(owner: ref<ShootDodgeBulletTimeKeySystem>) -> Void {
    this.m_owner = owner;
  }

  protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
    if Equals(ListenerAction.GetName(action), n"ShootDodgeBulletTime")
        && ListenerAction.IsButtonJustPressed(action) {
      let owner: ref<ShootDodgeBulletTimeKeySystem> = this.m_owner;
      if IsDefined(owner) {
        owner.OnKeyPressed();
      };
    };
    // C2SD-T46 / C2SD-T51: Shift held (Shift + Space is the Shootdodge).
    if Equals(ListenerAction.GetName(action), n"ShootDodgeModifier") {
      let ctrl: ref<ShootDodgeBulletTimeKeySystem> = this.m_owner;
      if IsDefined(ctrl) {
        if ListenerAction.IsButtonJustPressed(action) { ctrl.SetModifier(true); };
        if ListenerAction.IsButtonJustReleased(action) { ctrl.SetModifier(false); };
      };
    };
    return false;
  }
}

public class ShootDodgeBulletTimeKeySystem extends ScriptableSystem {
  private let m_listener: ref<ShootDodgeBulletTimeKeyListener>;
  private let m_player: wref<PlayerPuppet>;
  private let m_pending: Int32;
  private let m_total: Int32;
  private let m_modifier: Bool;

  public static func Get(gi: GameInstance) -> ref<ShootDodgeBulletTimeKeySystem> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"ShootDodgeBulletTimeKeySystem") as ShootDodgeBulletTimeKeySystem;
  }

  // Called when the player puppet attaches (each session start). Moves the listener to it.
  public func Attach(player: ref<PlayerPuppet>) -> Void {
    if !IsDefined(this.m_listener) {
      this.m_listener = new ShootDodgeBulletTimeKeyListener();
      this.m_listener.SetOwner(this);
    };
    let previous: ref<PlayerPuppet> = this.m_player;
    if IsDefined(previous) {
      previous.UnregisterInputListener(this.m_listener, n"ShootDodgeBulletTime");
      previous.UnregisterInputListener(this.m_listener, n"ShootDodgeModifier");
    };
    player.RegisterInputListener(this.m_listener, n"ShootDodgeBulletTime");
    player.RegisterInputListener(this.m_listener, n"ShootDodgeModifier");
    this.m_player = player;
    this.m_pending = 0;
    this.m_modifier = false;
  }

  public func SetModifier(held: Bool) -> Void {
    this.m_modifier = held;
  }

  // C2SD-T73: CET calls this when the on-foot controls go inactive (vehicle, menu, scene), where
  // the Shift release never reaches this listener, so the modifier can't stay stuck on.
  public func ReleaseModifier() -> Void {
    this.m_modifier = false;
  }

  public func OnKeyPressed() -> Void {
    this.m_pending += 1;
    this.m_total += 1;
  }

  // ---- CET side ----

  // Presses since the last call (normally 0 or 1), then forgets them.
  public func TakePresses() -> Int32 {
    let count: Int32 = this.m_pending;
    this.m_pending = 0;
    return count;
  }

  public func TotalPresses() -> Int32 {
    return this.m_total;
  }

  // C2SD-T46 / C2SD-T51: whether Shift is down right now (false without Input Loader).
  public func IsModifierHeld() -> Bool {
    return this.m_modifier;
  }

  public func IsListening() -> Bool {
    return IsDefined(this.m_player);
  }
}

@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let ret: Bool = wrappedMethod();
  let system: ref<ShootDodgeBulletTimeKeySystem> = ShootDodgeBulletTimeKeySystem.Get(this.GetGame());
  if IsDefined(system) {
    system.Attach(this);
  };
  return ret;
}
